package com.charan.apicrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class W2d2MorningApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
