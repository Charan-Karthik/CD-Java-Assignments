package com.charan.languages;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LanguagesApplicationTests {

	@Test
	void contextLoads() {
	}

}
