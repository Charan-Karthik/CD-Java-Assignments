package com.charan.loginreg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
