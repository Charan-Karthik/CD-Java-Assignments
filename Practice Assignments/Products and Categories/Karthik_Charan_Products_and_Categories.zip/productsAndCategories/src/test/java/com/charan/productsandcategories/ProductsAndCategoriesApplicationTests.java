package com.charan.productsandcategories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsAndCategoriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
