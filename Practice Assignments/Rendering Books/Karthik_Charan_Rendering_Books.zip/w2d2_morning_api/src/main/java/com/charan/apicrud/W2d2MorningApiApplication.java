package com.charan.apicrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class W2d2MorningApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(W2d2MorningApiApplication.class, args);
	}

}
